package com.example.data

import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

object GeminiApiClient {
    // Private portfolio/testing build: Gemini API key embedded as requested.
    private const val API_KEY = "AQ.Ab8RN6K7z6oYX9ECV2nm5Ji6d6mCkrDx9jyTkOhl3XSMG1btFQ"
    private const val TAG = "GeminiApiClient"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    data class ChatMessage(val role: String, val message: String)

    /**
     * Generate text response for conversational queries with memory context.
     */
    suspend fun chatWithAi(
        userMessage: String,
        history: List<ChatMessage>,
        language: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val apiKey = API_KEY
            if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
                return@withContext Result.failure(
                    IllegalStateException("Gemini API Key is missing or invalid. Please set your key in the Secrets panel.")
                )
            }

            val url = "$BASE_URL?key=$apiKey"

            val systemPrompt = """
                You are FF Assistant, a friendly, expert AI gaming coach and companion for mobile battle royale games.
                Your response must be in $language language.
                Keep responses concise, engaging, helpful, and natural for a mobile gamer.
                If asked casual questions, jokes, or status like 'Tu kaisa hai?', respond naturally and humorously.
                Do not give robotic or boilerplate replies.
            """.trimIndent()

            val rootJson = JSONObject()

            // System Instruction
            val systemObj = JSONObject()
            val sysParts = JSONArray()
            sysParts.put(JSONObject().put("text", systemPrompt))
            systemObj.put("parts", sysParts)
            rootJson.put("systemInstruction", systemObj)

            // Contents array
            val contentsArray = JSONArray()

            // Add history
            history.takeLast(6).forEach { chat ->
                val contentObj = JSONObject()
                contentObj.put("role", if (chat.role == "user") "user" else "model")
                val parts = JSONArray()
                parts.put(JSONObject().put("text", chat.message))
                contentObj.put("parts", parts)
                contentsArray.put(contentObj)
            }

            // Current message
            val currentObj = JSONObject()
            currentObj.put("role", "user")
            val currentParts = JSONArray()
            currentParts.put(JSONObject().put("text", userMessage))
            currentObj.put("parts", currentParts)
            contentsArray.put(currentObj)

            rootJson.put("contents", contentsArray)

            // Config
            val config = JSONObject()
            config.put("temperature", 0.7)
            config.put("maxOutputTokens", 250)
            rootJson.put("generationConfig", config)

            val body = rootJson.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()

            val response = okHttpClient.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                Log.e(TAG, "Chat API Error: ${response.code} $responseBody")
                return@withContext Result.failure(Exception("Gemini API Error (${response.code})"))
            }

            val jsonRes = JSONObject(responseBody)
            val candidates = jsonRes.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val candidate = candidates.getJSONObject(0)
                val content = candidate.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts != null && parts.length() > 0) {
                    val reply = parts.getJSONObject(0).optString("text", "").trim()
                    if (reply.isNotEmpty()) {
                        return@withContext Result.success(reply)
                    }
                }
            }

            Result.failure(Exception("Empty response from Gemini API"))
        } catch (e: Exception) {
            Log.e(TAG, "Chat error", e)
            Result.failure(e)
        }
    }

    /**
     * Generate a conversational response using the user's question plus the latest gameplay screenshot.
     */
    suspend fun chatWithAiAndImage(
        userMessage: String,
        bitmap: Bitmap,
        history: List<ChatMessage>,
        language: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val apiKey = API_KEY
            if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
                return@withContext Result.failure(
                    IllegalStateException("Gemini API Key is missing or invalid.")
                )
            }

            val url = "$BASE_URL?key=$apiKey"
            val imageStream = ByteArrayOutputStream()
            val scaledBitmap = if (bitmap.width > 640 || bitmap.height > 640) {
                val scale = 640f / Math.max(bitmap.width, bitmap.height)
                Bitmap.createScaledBitmap(
                    bitmap,
                    (bitmap.width * scale).toInt(),
                    (bitmap.height * scale).toInt(),
                    true
                )
            } else bitmap
            scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 70, imageStream)
            val base64Image = Base64.encodeToString(imageStream.toByteArray(), Base64.NO_WRAP)

            val rootJson = JSONObject()
            val systemObj = JSONObject()
            systemObj.put("parts", JSONArray().put(JSONObject().put("text", """
                You are FF Assistant, a friendly gaming coach and gaming buddy.
                Answer in $language. The user is speaking while playing a mobile battle royale game.
                Use the attached current gameplay screenshot when it contains useful visual information.
                Answer the user's exact question naturally and concisely.
                Never invent weapons, enemies, zones, positions, or statistics that are not visible.
                If the screenshot is insufficient, clearly say that it is not visible instead of guessing.
                For casual questions, respond naturally and humorously.
            """.trimIndent())))
            rootJson.put("systemInstruction", systemObj)

            val contents = JSONArray()
            history.takeLast(6).forEach { chat ->
                contents.put(
                    JSONObject()
                        .put("role", if (chat.role == "user") "user" else "model")
                        .put("parts", JSONArray().put(JSONObject().put("text", chat.message)))
                )
            }

            val currentParts = JSONArray()
                .put(JSONObject().put("text", userMessage))
                .put(
                    JSONObject().put(
                        "inlineData",
                        JSONObject()
                            .put("mimeType", "image/jpeg")
                            .put("data", base64Image)
                    )
                )
            contents.put(JSONObject().put("role", "user").put("parts", currentParts))
            rootJson.put("contents", contents)
            rootJson.put("generationConfig", JSONObject().put("temperature", 0.65).put("maxOutputTokens", 180))

            val request = Request.Builder()
                .url(url)
                .post(rootJson.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = okHttpClient.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                Log.e(TAG, "Voice vision API Error: ${response.code} $responseBody")
                return@withContext Result.failure(Exception("Gemini API Error (${response.code})"))
            }

            val jsonRes = JSONObject(responseBody)
            val candidates = jsonRes.optJSONArray("candidates")
            val reply = candidates?.optJSONObject(0)
                ?.optJSONObject("content")
                ?.optJSONArray("parts")
                ?.optJSONObject(0)
                ?.optString("text", "")
                ?.trim()
                .orEmpty()

            if (reply.isNotEmpty()) Result.success(reply)
            else Result.failure(Exception("Empty response from Gemini API"))
        } catch (e: Exception) {
            Log.e(TAG, "Voice vision chat error", e)
            Result.failure(e)
        }
    }

    /**
     * Analyze screen frame bitmap to provide short, contextual gameplay advice.
     */
    suspend fun analyzeScreenFrame(
        bitmap: Bitmap,
        language: String
    ): Result<String?> = withContext(Dispatchers.IO) {
        try {
            val apiKey = API_KEY
            if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
                return@withContext Result.failure(
                    IllegalStateException("Gemini API key is not configured.")
                )
            }

            val url = "$BASE_URL?key=$apiKey"

            // Compress bitmap to JPEG Base64
            val byteArrayOutputStream = ByteArrayOutputStream()
            // Scale down if large for performance
            val scaledBitmap = if (bitmap.width > 640 || bitmap.height > 640) {
                val scale = 640f / Math.max(bitmap.width, bitmap.height)
                Bitmap.createScaledBitmap(
                    bitmap,
                    (bitmap.width * scale).toInt(),
                    (bitmap.height * scale).toInt(),
                    true
                )
            } else {
                bitmap
            }

            scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 70, byteArrayOutputStream)
            val base64Image = Base64.encodeToString(byteArrayOutputStream.toByteArray(), Base64.NO_WRAP)

            val systemPrompt = """
                You are FF Assistant, an AI battle royale gaming coach inspecting a live gameplay screenshot.
                Your task: Look at the visual elements (minimap, safe zone, player position, open cover, fight indicators, weapons, HP level, loot).
                Language requirement: Output in $language language.
                
                RULES:
                1. Output ONLY 1 short, actionable, direct spoken advice sentence (10-15 words max).
                2. If there is NO urgent or meaningful advice to give, reply strictly with 'NO_ADVICE_NEEDED'.
                3. Never invent facts, exact enemy positions, or stats that are not clearly visible.
                4. Focus on zone rotation, cover/positioning, fight opportunities, low HP warning, or visible gear upgrades.
            """.trimIndent()

            val rootJson = JSONObject()

            val systemObj = JSONObject()
            val sysParts = JSONArray()
            sysParts.put(JSONObject().put("text", systemPrompt))
            systemObj.put("parts", sysParts)
            rootJson.put("systemInstruction", systemObj)

            val contentsArray = JSONArray()
            val userObj = JSONObject()
            userObj.put("role", "user")

            val userParts = JSONArray()
            userParts.put(JSONObject().put("text", "Analyze this current mobile gameplay screen and provide short tactical advice if needed."))

            val imagePart = JSONObject()
            val inlineData = JSONObject()
            inlineData.put("mimeType", "image/jpeg")
            inlineData.put("data", base64Image)
            imagePart.put("inlineData", inlineData)
            userParts.put(imagePart)

            userObj.put("parts", userParts)
            contentsArray.put(userObj)

            rootJson.put("contents", contentsArray)

            val config = JSONObject()
            config.put("temperature", 0.4)
            config.put("maxOutputTokens", 100)
            rootJson.put("generationConfig", config)

            val body = rootJson.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()

            val response = okHttpClient.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                Log.e(TAG, "Vision API Error: ${response.code} $responseBody")
                return@withContext Result.failure(Exception("Gemini Vision Error (${response.code})"))
            }

            val jsonRes = JSONObject(responseBody)
            val candidates = jsonRes.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val candidate = candidates.getJSONObject(0)
                val content = candidate.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts != null && parts.length() > 0) {
                    val advice = parts.getJSONObject(0).optString("text", "").trim()
                    if (advice.contains("NO_ADVICE_NEEDED", ignoreCase = true) || advice.isBlank()) {
                        return@withContext Result.success(null)
                    } else {
                        return@withContext Result.success(advice)
                    }
                }
            }

            Result.success(null)
        } catch (e: Exception) {
            Log.e(TAG, "Vision error", e)
            Result.failure(e)
        }
    }
}
